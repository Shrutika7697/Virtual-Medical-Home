package com.app.service;

import java.util.List;

import com.app.pojos.Admin;


public interface IAdminService {
	
	
	// list all admin
		List<Admin> getAllAdmin();
	// add new admin details
		Admin addAdminDetails(Admin transientPOJO);


}
