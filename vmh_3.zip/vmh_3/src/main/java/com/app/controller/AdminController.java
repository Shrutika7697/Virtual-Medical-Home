package com.app.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Admin;

import com.app.service.IAdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private IAdminService service;
	
	// RESTful end point or API end point or API provider
		@GetMapping
		public ResponseEntity<?> listAllAdmin() {
			System.out.println("in list all admins");
			// invoke service layer's method : controller --> service impl (p) --->JPA
			// repo's impl class(SC)
			List<Admin> admins = service.getAllAdmin();
			if (admins.isEmpty())//chck size
				// empty product list : set sts code : HTTP 204 (no contents)
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);//HttpStatus is a ENUM
			// in case of non empty list : OK, send the list
			return new ResponseEntity<>(admins, HttpStatus.OK);
		}
	
	@PostMapping
	private ResponseEntity<?> addAdmin(@RequestBody Admin p) {
		System.out.println("in add product " + p);
		try {
			Admin savedProduct = service.addAdminDetails(p);
			return new ResponseEntity<>(savedProduct, HttpStatus.OK);

		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
