package com.app.pojos;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="slot")
public class Slot {
	//slotid  slotdate  drid  slotstatus  strtTime  EndTime
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="slotid")
	private Integer slotid;
	
	@Column(name = "slot_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@JsonProperty(value = "slot-date")
	private LocalDate slotDate;
	
	@ManyToOne
	@JoinColumn(name="dr_id",nullable=false)
	private Doctor doctorSlots;
	
	@Enumerated(EnumType.ORDINAL)
	@Column(name = "slot_status", length = 20, nullable = false)
	private Status slotstatus;
	
	@Column(name="strt_time",nullable=false)
	@JsonProperty(value="strt-time")
	private LocalTime strttime;
	
	@Column(name="end_time",nullable=false)
	@JsonProperty(value="end-time")
	private LocalTime endtime;
	
	@OneToOne(mappedBy = "slot")//Non-owning side
    private Appointment appointment;
	
	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	
	
	

	public Slot() {
		System.out.println("in ctor of "+getClass().getName());
	}

	public Integer getSlotid() {
		return slotid;
	}

	public void setSlotid(Integer slotid) {
		this.slotid = slotid;
	}

	public LocalDate getSlotDate() {
		return slotDate;
	}

	public void setSlotDate(LocalDate slotDate) {
		this.slotDate = slotDate;
	}

	public Doctor getDoctorSlots() {
		return doctorSlots;
	}

	public void setDoctorSlots(Doctor doctorSlots) {
		this.doctorSlots = doctorSlots;
	}

	public Status getSlotstatus() {
		return slotstatus;
	}

	public void setSlotstatus(Status slotstatus) {
		this.slotstatus = slotstatus;
	}

	public LocalTime getStrttime() {
		return strttime;
	}

	public void setStrttime(LocalTime strttime) {
		this.strttime = strttime;
	}

	public LocalTime getEndtime() {
		return endtime;
	}

	public void setEndtime(LocalTime endtime) {
		this.endtime = endtime;
	}
	@Override
	public String toString() {
		return "Slot [slotid=" + slotid + ", slotDate=" + slotDate + ", doctorSlots=" + doctorSlots + ", slotstatus="
				+ slotstatus + ", strttime=" + strttime + ", endtime=" + endtime + ", appointment=" + appointment + "]";
	}

	
	
	

}
