package com.app.pojos;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="specialization")
public class Specialization {//speciaizationId    specializationName
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="specializationId")
	private Integer specializationId;
	
	@Column(length = 30,name="spclztn_name",unique=true)
	private String specializationName;
	
	@OneToOne(mappedBy = "specialization")//Non-owning side
    private Doctor doctor;
	
	public Specialization() {
		System.out.println("in ctor of "+getClass().getName());
	}
	
    public Integer getSpecializationId() {
		return specializationId;
	}

	public void setSpecializationId(Integer specializationId) {
		this.specializationId = specializationId;
	}

	public String getSpecializationName() {
		return specializationName;
	}

	public void setSpecializationName(String specializationName) {
		this.specializationName = specializationName;
	}

	@Override
	public String toString() {
		return "Specialization [specializationId=" + specializationId + ", specializationName=" + specializationName
				+ ", doctor=" + doctor + "]";
	}

	
	

}
