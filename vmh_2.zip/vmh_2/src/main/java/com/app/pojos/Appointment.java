package com.app.pojos;

import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="appointment")
public class Appointment {
	// appid dstatus pstatus drid ptntid slotid illness presciption
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="aptmnt_id")
	private Integer appointmentid;
	
	@Enumerated(EnumType.ORDINAL)
	@Column(name = "dr_status", length = 20, nullable = false)
	private Status drstatus;
	
	@Enumerated(EnumType.ORDINAL)
	@Column(name = "ptnt_status", length = 20, nullable = false)
	private Status patientstatus;
	
	@ManyToOne
	@JoinColumn(name="dr_id",nullable=false)
	private Doctor doctorAptmnts;
	
	//for creating foreign key slot_id in appointment table 
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "slotid", referencedColumnName = "slotid")
	private Slot slot; //foreign key 
	
	public Slot getSlot() {
		return slot;
	}

	public void setSlot(Slot slot) {
		this.slot = slot;
	}
	
	@ManyToOne
	@JoinColumn(name="p_id",nullable=false)
	private Patient pAppointments;
	

	public Patient getpAppointments() {
		return pAppointments;
	}

	public void setpAppointments(Patient pAppointments) {
		this.pAppointments = pAppointments;
	}

	@Column(length = 90,name="illness")
	private String illness;
	
	@Column(length = 90,name="prescriptions")
	private String prescriptions;

	public Appointment() {
		System.out.println("in ctor of "+getClass().getName());
	}

	public Integer getAppointmentid() {
		return appointmentid;
	}

	public void setAppointmentid(Integer appointmentid) {
		this.appointmentid = appointmentid;
	}

	public Status getDrstatus() {
		return drstatus;
	}

	public void setDrstatus(Status drstatus) {
		this.drstatus = drstatus;
	}

	public Status getPatientstatus() {
		return patientstatus;
	}

	public void setPatientstatus(Status patientstatus) {
		this.patientstatus = patientstatus;
	}

	public Doctor getDoctorAptmnts() {
		return doctorAptmnts;
	}

	public void setDoctorAptmnts(Doctor doctorAptmnts) {
		this.doctorAptmnts = doctorAptmnts;
	}


	public String getIllness() {
		return illness;
	}

	public void setIllness(String illness) {
		this.illness = illness;
	}

	public String getPrescriptions() {
		return prescriptions;
	}

	public void setPrescriptions(String prescriptions) {
		this.prescriptions = prescriptions;
	}

	@Override
	public String toString() {
		return "Appointment [appointmentid=" + appointmentid + ", drstatus=" + drstatus + ", patientstatus="
				+ patientstatus + ", doctorAptmnts=" + doctorAptmnts + ", slot=" + slot + ", pAppointments="
				+ pAppointments + ", illness=" + illness + ", prescriptions=" + prescriptions + "]";
	}
	
	
	
	
	
	
	
	
	

}
