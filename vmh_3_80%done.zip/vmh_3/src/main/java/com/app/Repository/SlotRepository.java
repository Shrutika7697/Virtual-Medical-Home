package com.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Slot;

public interface SlotRepository extends  JpaRepository< Slot ,Integer> {

}
