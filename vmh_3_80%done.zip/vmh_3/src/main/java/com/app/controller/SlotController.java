package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Repository.SlotRepository;
import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Doctor;
import com.app.pojos.Slot;

@RestController
@RequestMapping("/slot")
@Validated
public class SlotController {
	
	@Autowired
	private SlotRepository slotRepo;
	
	

	//using repo
	@GetMapping
	public ResponseEntity<?> getAllSlotDetails() {
		List<Slot> slotlist = slotRepo.findAll();
		//	return new ResponseEntity<>(emps, HttpStatus.OK);
		return ResponseEntity.ok(slotlist);//sts code : 200 , body : list of emps
	}
	
	
	//using repository
		// get specific emp details
		@GetMapping("/{slotID}")
		public ResponseEntity<?> getDoctorDetails(@PathVariable int slotID) {
			System.out.println("in get emp dtls " + slotID);
			Optional<Slot> optional = slotRepo.findById(slotID);
			if (optional.isPresent())
		//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
				return ResponseEntity.ok(optional.get());
			// invalid id
			ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
			return new ResponseEntity<>(resp, HttpStatus.NOT_FOUND);
		}
	
		
		//using repo
		// delete emp details
		@DeleteMapping("/{slotID}")
		public ResponseEntity<?> deleteEmpDetails(@PathVariable int slotID) {
		            System.out.println("in delete emp " + slotID);
				// check if emp exists
			        Optional<Slot> optional = slotRepo.findById(slotID);
					if (optional.isPresent()) {
						slotRepo.deleteById(slotID);
						return new ResponseEntity<>(new ResponseDTO("Emp rec deleted with ID " + slotID), HttpStatus.OK);
					} else
						 throw new ResourceNotFoundException("Emp ID Invalid : rec deletion failed");
					//	throw new RuntimeException("my own err mesg");

				}
		
	
	
	

}
