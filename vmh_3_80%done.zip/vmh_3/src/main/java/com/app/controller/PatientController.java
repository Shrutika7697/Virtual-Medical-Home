package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Repository.PatientRepository;
import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Doctor;
import com.app.pojos.Patient;

@RestController
@RequestMapping("/patient")
@Validated
public class PatientController {
	
	@Autowired
	private PatientRepository ptntRepo;
	
	

	//using repo
	@GetMapping
	public ResponseEntity<?> getAllptntDetails() {
		List<Patient> patients = ptntRepo.findAll();
	//	return new ResponseEntity<>(emps, HttpStatus.OK);
		return ResponseEntity.ok(patients);//sts code : 200 , body : list of emps
	}
	
	
	//using repository
		// get specific emp details
		@GetMapping("/{ptntID}")
		public ResponseEntity<?> getDoctorDetails(@PathVariable int ptntID) {
			System.out.println("in get emp dtls " + ptntID);
			Optional<Patient> optional = ptntRepo.findById(ptntID);
			if (optional.isPresent())
		//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
				return ResponseEntity.ok(optional.get());
			// invalid id
			ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
			return new ResponseEntity<>(resp, HttpStatus.NOT_FOUND);
		}
	
		//using repo
		// delete emp details
		@DeleteMapping("/{ptntID}")
		public ResponseEntity<?> deleteEmpDetails(@PathVariable int ptntID) {
		            System.out.println("in delete emp " + ptntID);
				// check if emp exists
			        Optional<Patient> optional = ptntRepo.findById(ptntID);
					if (optional.isPresent()) {
						ptntRepo.deleteById(ptntID);
						return new ResponseEntity<>(new ResponseDTO("Emp rec deleted with ID " + ptntID), HttpStatus.OK);
					} else
						 throw new ResourceNotFoundException("Emp ID Invalid : rec deletion failed");
					//	throw new RuntimeException("my own err mesg");

				}
		
	
	
	

}
