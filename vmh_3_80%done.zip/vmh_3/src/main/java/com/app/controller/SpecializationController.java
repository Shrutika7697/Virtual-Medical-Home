package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Repository.SpecializationRepository;
import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Specialization;
import com.app.service.ISpeclztnService;

@RestController
@RequestMapping("/specialization")
@Validated
public class SpecializationController {
	
	@Autowired
	private SpecializationRepository spcltnRepo;
	
	
	@Autowired
	private ISpeclztnService service;

	
	
	
	//using repo
	@GetMapping
		public ResponseEntity<?> getAllSpecializationDetails() {
			List<Specialization> spclztns = spcltnRepo.findAll();
		//	return new ResponseEntity<>(emps, HttpStatus.OK);
			return ResponseEntity.ok(spclztns);//sts code : 200 , body : list of emps
		}
		
		
		
		//using repository
				// get specific emp details
				@GetMapping("/{spclztnID}")
				public ResponseEntity<?> getSpecializtnDetails(@PathVariable int spclztnID) {
					System.out.println("in get emp dtls " + spclztnID);
					Optional<Specialization> optional = spcltnRepo.findById(spclztnID);
					if (optional.isPresent())
				//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
						return ResponseEntity.ok(optional.get());
					// invalid id
					ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
					return new ResponseEntity<>(resp, HttpStatus.NOT_FOUND);
				}

				
				
				//using repo
				@PostMapping
				public ResponseEntity<?> addSpclztnDetails(@RequestBody  Specialization s) {
					System.out.println("in add emp " + s);
					return new ResponseEntity<>(spcltnRepo.save(s), HttpStatus.CREATED);
				}
				
				/*
				
				
				
				@PostMapping
				public ResponseEntity<?> addProduct(@RequestBody Specialization p) {
					System.out.println("in add product " + p);
					try {
						Specialization savedProduct = service.addSpclztnDetails(p);
						return new ResponseEntity<>(savedProduct, HttpStatus.OK);

					} catch (RuntimeException e) {
						e.printStackTrace();
						return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
				*/
				
				
				
				
				
				
				
				
				//using repo
				// delete emp details
					@DeleteMapping("/{spclztnID}")
					public ResponseEntity<?> deleteEmpDetails(@PathVariable int spclztnID) {
						System.out.println("in delete emp " + spclztnID);
						// check if emp exists
						Optional<Specialization> optional = spcltnRepo.findById(spclztnID);
						if (optional.isPresent()) {
							spcltnRepo.deleteById(spclztnID);
							return new ResponseEntity<>(new ResponseDTO("Emp rec deleted with ID " + spclztnID), HttpStatus.OK);
						} else
							 throw new ResourceNotFoundException("Emp ID Invalid : rec deletion failed");
						//	throw new RuntimeException("my own err mesg");

					}
				
				
				
				
}
