package com.app.controller;

import java.util.List;

import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Repository.AdminRepository;
import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Admin;
import com.app.service.IAdminService;

@RestController
@RequestMapping("/admin")
@Validated
public class AdminController {
	
	@Autowired
	private IAdminService service;
	
	@Autowired
	private AdminRepository dao;
	
	/*
	// RESTful end point or API end point or API provider
		@GetMapping
		public ResponseEntity<?> listAllAdmin() {
			System.out.println("in list all admins");
			// invoke service layer's method : controller --> service impl (p) --->JPA
			// repo's impl class(SC)
			List<Admin> admins = service.getAllAdmin();
			if (admins.isEmpty())//chck size
				// empty product list : set sts code : HTTP 204 (no contents)
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);//HttpStatus is a ENUM
			// in case of non empty list : OK, send the list
			return new ResponseEntity<>(admins, HttpStatus.OK);
		}
	*/
	
	
	//using repo
	@GetMapping
	public ResponseEntity<?> getAllAdminDetails() {
		List<Admin> admins = dao.findAll();
	//	return new ResponseEntity<>(emps, HttpStatus.OK);
		return ResponseEntity.ok(admins);//sts code : 200 , body : list of emps
	}
  
	
	
	
	
	
	/*
		//using service
		// get prduct details by its name : supplied by clnt using path var
		@GetMapping("/{adminId}")
		public ResponseEntity<?> getProductDetails(@PathVariable Integer adminId) {
			System.out.println("in get prod details " + adminId);
			// invoke service method
			Optional<Admin> adminDetails = service.getAdminDetails(adminId);
			// valid name : HTTP 200 , marshalled product details
			if (adminDetails.isPresent())
				return new ResponseEntity<>(adminDetails.get(), HttpStatus.OK);
			// in case of invalid name : HTTP 404
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		
		*/
	
	
		//using repository
		// get specific emp details
		@GetMapping("/{adminId}")
		public ResponseEntity<?> getEmpDetails(@PathVariable int adminId) {
			System.out.println("in get emp dtls " + adminId);
			Optional<Admin> optional = dao.findById(adminId);
			if (optional.isPresent())
		//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
				return ResponseEntity.ok(optional.get());
			// invalid id
			ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
			return new ResponseEntity<>(resp, HttpStatus.NOT_FOUND);
		}
		
		
		
		
		
		
		
		
		
		/*
	
	//using service
	@PostMapping
	private ResponseEntity<?> addAdmin(@RequestBody Admin p) {
		System.out.println("in add product " + p);
		try {
			Admin savedProduct = service.addAdminDetails(p);
			return new ResponseEntity<>(savedProduct, HttpStatus.OK);

		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	*/
		
		//using repo
		@PostMapping
		public ResponseEntity<?> addAdminDetails(@RequestBody  Admin e) {
			System.out.println("in add emp " + e);
			return new ResponseEntity<>(dao.save(e), HttpStatus.CREATED);
		}
		
		
		
	//using repo
	// delete emp details
		@DeleteMapping("/{adminId}")
		public ResponseEntity<?> deleteEmpDetails(@PathVariable int adminId) {
			System.out.println("in delete emp " + adminId);
			// check if emp exists
			Optional<Admin> optional = dao.findById(adminId);
			if (optional.isPresent()) {
				dao.deleteById(adminId);
				return new ResponseEntity<>(new ResponseDTO("Emp rec deleted with ID " + adminId), HttpStatus.OK);
			} else
				 throw new ResourceNotFoundException("Emp ID Invalid : rec deletion failed");
			//	throw new RuntimeException("my own err mesg");

		}
		
		
		//using repository
		@PutMapping("/{adminId}")
		public ResponseEntity<?> updateEmpDetails(@PathVariable int adminId, @RequestBody Admin admin) {
			System.out.println("in update emp " + adminId + " " + admin);
			// check if emp exists
			Optional<Admin> optional = dao.findById(adminId);
			if (optional.isPresent()) {
				// emp id valid : update the same
				Admin existingAdmin = optional.get();// DETACHED
				System.out.println("existing emp " + existingAdmin);
				//existingAdmin.setAdminid(admin.getAdminid());
				existingAdmin.setAdminUsername(admin.getAdminUsername());
				existingAdmin.setAdminPassword(admin.getAdminPassword());
				// update detached POJO
				return new ResponseEntity<>(dao.save(existingAdmin), HttpStatus.OK);
				// save or update (insert: transient(value of ID : default
				// or non default value BUT existing on DB -- update
			} else
				throw new ResourceNotFoundException("Emp ID Invalid");

		}
	
	
	
	
}
	
	
