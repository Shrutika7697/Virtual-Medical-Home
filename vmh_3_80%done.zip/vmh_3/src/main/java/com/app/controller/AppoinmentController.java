package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Repository.AppointmentRepository;
import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Appointment;
import com.app.pojos.Doctor;

@RestController
@RequestMapping("/appointment")
@Validated
public class AppoinmentController {
	
	@Autowired
	 private AppointmentRepository  appRepo;
	
	//using repo
		@GetMapping
		public ResponseEntity<?> getAllApptmntDetails() {
			List<Appointment> applist = appRepo.findAll();
			//	return new ResponseEntity<>(emps, HttpStatus.OK);
			return ResponseEntity.ok(applist);//sts code : 200 , body : list of emps
		}
		
		
		//using repository
		// get specific emp details
		@GetMapping("/{appID}")
		public ResponseEntity<?> getApptmntDetails(@PathVariable int appID) {
			System.out.println("in get emp dtls " + appID);
			Optional<Appointment> optional = appRepo.findById(appID);
			if (optional.isPresent())
		//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
				return ResponseEntity.ok(optional.get());
			// invalid id
			ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
			return new ResponseEntity<>(resp, HttpStatus.NOT_FOUND);
		}
		
		
		
		
		

}
