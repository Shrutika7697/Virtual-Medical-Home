package com.app.controller;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Repository.DoctorRepository;
import com.app.Repository.SpecializationRepository;
import com.app.cust_excs.ResourceNotFoundException;
import com.app.dto.ErrorResponse;
import com.app.dto.ResponseDTO;
import com.app.pojos.Admin;
import com.app.pojos.Doctor;

import com.app.pojos.Specialization;

@RestController
@RequestMapping("/doctor")
@Validated
public class DoctorController {
	
	@Autowired
	private DoctorRepository drRepo;
	
	@Autowired
	private SpecializationRepository spcltnRepo;
	
	//using repo
	@GetMapping
	public ResponseEntity<?> getAllDoctorDetails() {
		List<Doctor> doctorlist = drRepo.findAll();
		//	return new ResponseEntity<>(emps, HttpStatus.OK);
		return ResponseEntity.ok(doctorlist);//sts code : 200 , body : list of emps
	}

	//using repository
	// get specific emp details
	@GetMapping("/{doctorID}")
	public ResponseEntity<?> getDoctorDetails(@PathVariable int doctorID) {
		System.out.println("in get emp dtls " + doctorID);
		Optional<Doctor> optional = drRepo.findById(doctorID);
		if (optional.isPresent())
	//		return new ResponseEntity<>(optional.get(), HttpStatus.OK);
			return ResponseEntity.ok(optional.get());
		// invalid id
		ErrorResponse resp = new ErrorResponse("Emp Id Invalid", "Must Supply valid Emp Id");
		return new ResponseEntity<>(resp, HttpStatus.NOT_FOUND);
	}
	
    /*
	//using repo
	@PostMapping
	public ResponseEntity<?> addDoctorDetails(@RequestBody  Doctor s) {
		//s.setSpecialization(s.getSpecialization());
		//Integer spclztnID=s.getSpecialization().getSpecializationId();
		Specialization spctln=s.getSpecialization();
		s.setSpecialization(spctln);
		//Optional<Specialization> optional = spcltnRepo.findById(spclztnID);
		//Specialization sp=spcltnRepo.getOne(spclztnID);
		System.out.println("in add emp " + s);
		return new ResponseEntity<>(drRepo.save(s), HttpStatus.CREATED);
	}
	*/
	
	//using repo
	@PostMapping
	public ResponseEntity<?> addDoctorDetails(@RequestBody  Doctor s) {
		System.out.println("in add emp " + s);
		return new ResponseEntity<>(drRepo.save(s), HttpStatus.CREATED);
	}
	
	
	
	//using repo
	// delete emp details
	@DeleteMapping("/{drId}")
	public ResponseEntity<?> deleteEmpDetails(@PathVariable int drId) {
	            System.out.println("in delete emp " + drId);
			// check if emp exists
		        Optional<Doctor> optional = drRepo.findById(drId);
				if (optional.isPresent()) {
					drRepo.deleteById(drId);
					return new ResponseEntity<>(new ResponseDTO("Emp rec deleted with ID " + drId), HttpStatus.OK);
				} else
					 throw new ResourceNotFoundException("Emp ID Invalid : rec deletion failed");
				//	throw new RuntimeException("my own err mesg");

			}
	
	
	//using repository
			@PutMapping("/{drId}")
			public ResponseEntity<?> updateEmpDetails(@PathVariable int drId, @RequestBody Doctor dr) {
				System.out.println("in update emp " + drId + " " + dr);
				// check if emp exists
				Optional<Doctor> optional = drRepo.findById(drId);
				if (optional.isPresent()) {
					// emp id valid : update the same
					Doctor existingDr = optional.get();// DETACHED
					System.out.println("existing emp " + existingDr);
					//existingAdmin.setAdminid(admin.getAdminid());
					existingDr.setDrName(dr.getDrName());
					existingDr.setEmailID(dr.getEmailID());
					existingDr.setExperience(dr.getExperience());
					existingDr.setGender(dr.getGender());
					existingDr.setConsultationCost(dr.getConsultationCost());
					existingDr.setDesignation(dr.getDesignation());
					existingDr.setSpecializtnDr(dr.getSpecializtnDr());
					// update detached POJO
					return new ResponseEntity<>(drRepo.save(existingDr), HttpStatus.OK);
					// save or update (insert: transient(value of ID : default
					// or non default value BUT existing on DB -- update
				} else
					throw new ResourceNotFoundException("Emp ID Invalid");

			}
	
	
	
	
	
	
}
