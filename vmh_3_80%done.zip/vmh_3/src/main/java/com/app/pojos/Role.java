package com.app.pojos;

public enum Role {
	ADMIN,DOCTOR,PATIENT

}
