package com.app.pojos;

public enum Status {
	TRUE,FALSE

}
