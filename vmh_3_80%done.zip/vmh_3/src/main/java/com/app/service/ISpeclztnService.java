package com.app.service;

import com.app.pojos.Specialization;

public interface ISpeclztnService {
	
	// add new admin details
	Specialization addSpclztnDetails(Specialization transientPOJO);

}


